from setuptools import setup

setup(


name= "Paquete_EZEQUIEL",
version= "1.0",
description= "paquete distribuido",
author= "EZEQUIEL - Python",
author_email= "ezequielleston9@gmail.com",

packages= ["Paquete_EZEQUIEL"]


)